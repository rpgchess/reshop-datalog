//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DpiAwarenessContext.rc
//
#define IDM_EXIT                        103
#define IDM_DPIUNAWARE                  104
#define IDM_SHOWDIALOG                  105
#define IDC_MAINMENU                    109
#define IDD_DIALOG1                     129
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_UNAWARE              1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON_SYSTEM               1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON_81                   1002
#define IDC_BUTTON4                     1003
#define IDC_BUTTON_1607                 1003
#define IDC_BUTTON5                     1004
#define IDC_BUTTON_1703                 1004
#define IDC_BUTTON6                     1005
#define IDC_BUTTON_1803                 1005
#define IDC_EDIT1                       1007
#define ID_FILE_ITEM2                   32771
#define ID_FILE_ITEM3                   32772
#define ID_ITEM1_SUBITEM1               32773
#define ID_ITEM1_SUBITEM2               32774
#define ID_ITEM1_SUBITEM3               32775
#define ID_ITEM1_SUBITEM4               32776
#define ID_EDIT_EDITITEM1               32777
#define ID_EDIT_EDITITEM2               32778
#define ID_EDIT_EDITITEM3               32779
#define ID_VIEW_VIEWITEM1               32780
#define ID_VIEW_VIEWITEM2               32781
#define ID_VIEW_VIEWITEM3               32782
#define ID_VIEWITEM1_VIEWSUBITEM1       32783
#define ID_VIEWITEM1_VIEWSUBITEM2       32784
#define ID_VIEWITEM1_VIEWSUBITEM3       32785
#define ID_EDITITEM1_EDITSUBITEM1       32786
#define ID_EDITITEM1_EDITSUBITEM2       32787
#define ID_EDITITEM1_EDITSUBITEM3       32788
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
